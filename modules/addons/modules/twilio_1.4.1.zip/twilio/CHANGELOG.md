# Changelog

08.01.2023 - ver 1.4.1

- Added: Custom Message with Dynamic Content

08.03.2021 - ver 1.4

- Added: Global Settings

18.11.2021 - ver 1.3.1

- Added: Core 1.16 compatibility

21.07.2021 - ver 1.3

- Added: Core v1.14.2 compatibility
- Improved: jQuery 3.6.0 compatibility
- Added: OTP Verification

24.05.2021 - ver 1.2.2

- Added: Core v1.14 compatibility
- Removed: i18n messages

09.04.2021 - ver 1.2.1

- Added: Compatibility with Core 1.13

28.06.2020 - ver 1.2

- Added: Send confirmation message via SMS by using placeholders.
- Added: Event and Conditions
- Added: Multiple configurations per form
- Improved: Show Configuration Name in Gridview

19.03.2020 - ver 1.1

- Added: Compatibility with RBAC system (core v1.10)
- Added: Bulk Actions
- Added: GridView Filters

05.12.2017 - Initial release